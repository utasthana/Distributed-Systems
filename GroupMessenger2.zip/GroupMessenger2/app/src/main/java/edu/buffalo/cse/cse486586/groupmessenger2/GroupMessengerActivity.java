package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.UserHandle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Date;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 *
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {
    static int track = 0;
    String myPort;

    HashMap<String,String> map = new HashMap<String,String>();
    LinkedHashMap sortedMap1;

   // Dbhandler dbh1=new Dbhandler(new Context());

    // mySQLite myDB;
    // Vector<Message> Store;
    static final String TAG = GroupMessengerActivity.class.getSimpleName();


   // static Vector<String> TEST_PORTS;

    static final int SERVER_PORT = 10000;
      /*
             * Log is a good way to debug your code. LogCat prints out all the messages that
             * Log class writes.
             *
             * Please read http://developer.android.com/tools/debugging/debugging-projects.html
             * and http://developer.android.com/tools/debugging/debugging-log.html
             * for more information on debugging.
             */
    String msz="error encountered";

  //  Log.e("RAW_MESSAGE", "Message Received: ");

    TreeMap<String,String> buildmap;

  //  Vector<String> dupCheck;
    static final String[] REMOTE_PORT = {"11108","11112","11116","11120","11124"};
    @Override
    public void sendBroadcast(Intent intent, String receiverPermission)
    {

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        //  myDB = new mySQLite(this);
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        Button send = (Button) findViewById(R.id.button4);
        final EditText editText = (EditText) findViewById(R.id.editText1);
        final TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        // Store = new Vector<Message>();
        Uri.Builder newUri = new Uri.Builder();
        newUri.authority("content");
        newUri.scheme("edu.buffalo.cse.cse486586.groupmessenger2.provider");
        newUri.build();

        // Vector<String> TEST_PORTS = new Vector<String>();
        ArrayList<String> ports_num = new ArrayList<String>();

        int xyz=11108;
       for(int i=0;i<5;i++) {

           xyz+=4;
           String tmp=Integer.toString(xyz);
           ports_num.add(tmp);

       }
     //Referenced http://stackoverflow.com/questions/12947088/java-treemap-comparator
        buildmap = new TreeMap<String,String>(new Comparator<String>() {
            @Override
            public int compare(String t1, String t2) {
                if(t1.compareTo(t2)!=0)
                    return t1.compareTo(t2);
                else return 1;
            }});


        //dupCheck = new Vector<String>();

        try {

            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            /*
             * Log is a good way to debug your code. LogCat prints out all the messages that
             * Log class writes.
             *
             * Please read http://developer.android.com/tools/debugging/debugging-projects.html
             * and http://developer.android.com/tools/debugging/debugging-log.html
             * for more information on debugging.
             */
            Log.e(TAG, "Can't create a ServerSocket");
            return;
        }

        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));

        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //from previous assignment
                String msg = editText.getText().toString() + "\n";
                tv.append(msg);
                //toSend = new Message(myPort,msg);
                editText.setText(""); // This is one way to reset the input box.
                Date currentDate= new Date();
                Timestamp time = new Timestamp(currentDate.getTime());
                //Message temp = new Message(myPort, msgs[0], time);////
                String times = ""+time;
                Sender0 sender0 = new Sender0(msg,times); //Sender for port 11108
                Sender1 sender1 = new Sender1(msg,times);//Sender for port 11112
                Sender2 sender2 = new Sender2(msg,times);//Sender for port 11116
                Sender3 sender3 = new Sender3(msg,times);//Sender for port 11120
                Sender4 sender4 = new Sender4(msg,times);//Sender for port 11124
//                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort);
            }
        });
    }
//I have Referred: http://stackoverflow.com/questions/8119366/sorting-hashmap-by-values
    public static LinkedHashMap sortHashMapByValuesD(HashMap passedMap) {
        List mapKeys = new ArrayList(passedMap.keySet());
        List mapValues = new ArrayList(passedMap.values());
        Collections.sort(mapValues);
        Collections.sort(mapKeys);

        LinkedHashMap sortedMap = new LinkedHashMap();

        Iterator valueIt = mapValues.iterator();
        while (valueIt.hasNext()) {
            Object val = valueIt.next();
            Iterator keyIt = mapKeys.iterator();

            while (keyIt.hasNext()) {
                Object key = keyIt.next();
                String comp1 = passedMap.get(key).toString();
                String comp2 = val.toString();

                if (comp1.equals(comp2)){
                    passedMap.remove(key);
                    mapKeys.remove(key);
                    sortedMap.put(key,val);
                    break;
                }

            }

        }
        return sortedMap;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets){
            ServerSocket serverSocket = sockets[0];
            Socket socket = new Socket();
            try {
                while(true) {
                    socket = serverSocket.accept();

                    InputStream inputstream = socket.getInputStream();
                    BufferedInputStream bis=new BufferedInputStream(inputstream);
                    DataInputStream in = new DataInputStream(bis);
                    //  String text = in.readUTF();
                    //Message mg = new Message();
                    //mg=(Message) text;

                    String msg = ""+in.readUTF();
                    String time = ""+in.readUTF();

                    //  String temp = text.getTime() + "||" + text.getText();
                    String temp = time+"||"+msg;
                    Log.d("RAW_MESSAGE", "Message Received: " + temp);
                    publishProgress(temp);
                    in.close();

//----------------added the change here ---------------------------------------------
                    // if (socket.isInputShutdown()) return null;

                }} catch (IOException e) {
                e.printStackTrace();
            } finally{
                try {
                    socket.close();
                    serverSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            return null;
        }
        private boolean isRemotePortInUse(int portNumber) {
            try {
                // Socket try to open a REMOTE port
                new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), portNumber).close();

                return true;
            } catch(Exception e) {

                return false;
            }
        }

        private Uri buildUri(String scheme, String authority) {
            Uri.Builder uriBuilder = new Uri.Builder();
            uriBuilder.authority(authority);
            uriBuilder.scheme(scheme);
            return uriBuilder.build();
        }


        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */

            String strReceived = strings[0].trim();
            String strReceived1 = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);
            remoteTextView.append(strReceived + "\t\n");
            TextView ltv = (TextView) findViewById(R.id.textView1);
            ltv.append(strReceived1);
            ltv.append("\t\n");


            Uri muri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger2.provider");

            ContentValues keyValueToInsert = new ContentValues();
            keyValueToInsert.put("value",strReceived);
            keyValueToInsert.put("key", Integer.toString(track++));

            getContentResolver().insert(muri,keyValueToInsert);
            try {
                sequencer(strReceived);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            /*
             * The following code creates a file in the AVD's internal storage and stores a file.
             *
             * For more information on file I/O on Android, please take a look at
             * http://developer.android.com/training/basics/data-storage/files.html
             */

            return;
        }
    }
    public void sequencer(String received) throws ParseException {

        String gotmes[] = received.split("\\|\\|");
        String time = gotmes[0];

        String msgToSend = gotmes[1];


        buildmap.put(time,msgToSend);
        map.put(time, msgToSend);
        LinkedHashMap sortedMap1 = new LinkedHashMap();
        sortedMap1=sortHashMapByValuesD(map);
        int seq = 0;
        String key;

        Set keys = map.keySet();
        for (Iterator i = keys.iterator(); i.hasNext();) {
            String testkey = (String) i.next();
            String value = (String) map.get(testkey);
            int sq=(Integer) seq;
            //testkey = ""+sq;
            ContentValues keyValueToInsert = new ContentValues();
            keyValueToInsert.put("key", "" + testkey);
            keyValueToInsert.put("value", value);
            //System.out.println(testkey + " = " + value);
        }


       for(String value : buildmap.values()){

            key = ""+seq++;
            ContentValues keyValueToInsert = new ContentValues();
            keyValueToInsert.put("key", "" + key);
            keyValueToInsert.put("value", value);


            Uri newUri = getContentResolver().insert(
                    Uri.parse("content://edu.buffalo.cse.cse486586.groupmessenger2.provider"),    // assume we already created a Uri object with our provider URI
                    keyValueToInsert
            );



            //   Uri muri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger1.provider");

            ContentValues keyValueToInsert1 = new ContentValues();
            keyValueToInsert.put("value",value);
            keyValueToInsert.put("key", Integer.toString(track++));

            //  getContentResolver().insert(muri,keyValueToInsert);
//                }

        }


    }

    public class Sender0 extends Thread {
        String msg;
        String time;
        public Sender0(String msg, String time) {
            this.msg = msg;
            this.time = time;
            start();
        }

        public void run() {
            try {
                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        11108);
                socket.setSoTimeout(300);
                socket.setTcpNoDelay(true);
                DataOutputStream dos =
                        new DataOutputStream(
                                new BufferedOutputStream( socket.getOutputStream() ));
                dos.writeUTF(msg);
                dos.writeUTF(time);
                dos.flush();
                socket.close();

            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {
            try {
                String msgToSend = msgs[0];
                Socket socket;


                for(int i=0;i<5;i++) {

                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(REMOTE_PORT[i]));


                    socket.setTcpNoDelay(true);
                    // String msgToSend = msgs[0];
                    OutputStream os = socket.getOutputStream();
                    OutputStreamWriter osw = new OutputStreamWriter(os);
                    BufferedWriter bw = new BufferedWriter(osw);
                    bw.write(msgToSend);

                    bw.flush();

                    //System.out.print(msgToSend);
                    socket.close();
                }


            } catch (UnknownHostException e) {
//                e.printStackTrace();
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
//                e.printStackTrace();
                Log.e(TAG, "ClientTask socket IOException");
            }

            return null;
        }

    }

    public class Sender1 extends Thread {
        String msg;
        String time;
        public Sender1(String msg, String time) {
            this.msg = msg;
            String msgToSend =msg;
            this.time = time;
            start();
        }

        public void run() {
            try {
                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        11112);
                socket.setSoTimeout(330);
                socket.setTcpNoDelay(true);
                DataOutputStream dos =
                        new DataOutputStream(
                                new BufferedOutputStream( socket.getOutputStream() ));
                dos.writeUTF(msg);
                dos.writeUTF(time);
                String msgToSend =msg;
                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                //   bw.write(msgToSend);
                // bw.flush();


                dos.flush();
                socket.close();

            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
        }
    }
    public class Sender2 extends Thread {
        String msg;
        String time;
        public Sender2(String msg, String time) {
            this.msg = msg;
            this.time = time;
            start();
        }

        public void run() {
            try {
                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        11116);
                socket.setSoTimeout(330);
                String msgToSend =msg;
                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                socket.setTcpNoDelay(true);
                DataOutputStream dos =
                        new DataOutputStream(
                                new BufferedOutputStream( socket.getOutputStream() ));
                dos.writeUTF(msg);
                dos.writeUTF(time);
                dos.flush();
                socket.close();

            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
        }
    }
    public class Sender3 extends Thread {
        String msg;
        String time;
        public Sender3(String msg, String time) {
            this.msg = msg;
            this.time = time;
            start();
        }

        public void run() {
            try {
                String msgToSend =msg;

                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        11120);
                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                socket.setSoTimeout(330);
                socket.setTcpNoDelay(true);
                DataOutputStream dos =
                        new DataOutputStream(
                                new BufferedOutputStream( socket.getOutputStream() ));
                dos.writeUTF(msg);
                dos.writeUTF(time);
                dos.flush();
                socket.close();

            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
        }
    }
    public class Sender4 extends Thread {
        String msg;
        String time;
        public Sender4(String msg, String time) {
            this.msg = msg;
            this.time = time;
            start();
        }

        public void run() {
            try {
                String msgToSend =msg;
                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        11124);

                OutputStream os = socket.getOutputStream();

                socket.setSoTimeout(330);
                socket.setTcpNoDelay(true);
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                DataOutputStream dos =
                        new DataOutputStream(
                                new BufferedOutputStream( socket.getOutputStream() ));
                dos.writeUTF(msg);
                dos.writeUTF(time);
                dos.flush();
                socket.close();
            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
        }
    }



}

abstract class ContextWrapper extends Context
{  ContextWrapper mBase;
    @Override
    public Context getApplicationContext() {

        return mBase.getApplicationContext();
    }
    protected ContextWrapper attachBaseContext(Context base) {
        if (mBase != null) {
            throw new IllegalStateException("Base context already set");
        }
        mBase = (ContextWrapper)base;
        return mBase;
    }
  /*  @Override
    public void sendBroadcast(Intent intent, String receiverPermission)
    {

    }*/
}