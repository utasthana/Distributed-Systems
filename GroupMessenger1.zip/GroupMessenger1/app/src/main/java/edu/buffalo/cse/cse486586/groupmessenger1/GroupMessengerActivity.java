package edu.buffalo.cse.cse486586.groupmessenger1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.UnknownHostException;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 *
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {
    static int track = 0;
     static final int SERVER_PORT = 10000;
    static final String TAG = GroupMessengerActivity.class.getSimpleName();
    static final String[] REMOTE_PORT = {"11108","11112","11116","11120","11124"};
  

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);
           TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        
        TextView viewtext = (TextView) findViewById(R.id.textView1);
        viewtext.setMovementMethod(new ScrollingMovementMethod());
       
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(viewtext, getContentResolver()));

      
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));

        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
//            Log.e(TAG, "ServerSocket success 1");
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
//            Log.e(TAG, "ServerSocket success 2");
        } catch (IOException e) {
//            e.printStackTrace();
            Log.e(TAG, "Can't create a ServerSocket");
            return;
        }

        final EditText editText = (EditText) findViewById(R.id.editText1);

        final Button send=(Button) findViewById(R.id.button4);

        send.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String displaymsg = editText.getText().toString() + "\n";
                editText.setText(""); // reset the input box.
				if (!displaymsg.trim().equalsIgnoreCase("")) {
                    ((TextView) v).append(displaymsg); // This is one way to display a string.
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, displaymsg, myPort);
                }

               }
        });
   }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { //nothing to implement here
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
// code from PA-1
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            try {
                while(true) {
                    
            Socket socket = serverSocket.accept();
                    InputStream is = socket.getInputStream();
                    InputStreamReader isr = new InputStreamReader(is);
                    DataInputStream dstr = new DataInputStream(is);


            BufferedReader br = new BufferedReader(isr);

                    byte[] received = new byte[128];//msg maximum character size is expected to be 128
                    dstr.read(received);
                    socket.close(); //closing the socket once the msg is read
                    publishProgress(new String(received));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
         
		   private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }
        protected void onProgressUpdate(String...strings) {

            String strReceived = strings[0].trim();
           
            TextView localTextView = (TextView) findViewById(R.id.textView1);
            localTextView.append(strReceived);
            localTextView.append("\n");

            
            Uri muri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger1.provider");

            ContentValues keyValueToInsert = new ContentValues();
            keyValueToInsert.put("value",strReceived);
            keyValueToInsert.put("key", Integer.toString(track++));

            getContentResolver().insert(muri,keyValueToInsert);
            
        }
    }
  

    /***
     * ClientTask is an AsyncTask that should send a string over the network.
     * It is created by ClientTask.executeOnExecutor() call whenever OnKeyListener.onKey() detects
     * an enter key press event.
     *
     * @author stevko
     *
     */
    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {
            try {
			  String msgToSend = msgs[0];
                Socket socket;
                
              
                for(int i=0;i<5;i++) {
                   
                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(REMOTE_PORT[i]));
                   
                    
				socket.setTcpNoDelay(true);
               // String msgToSend = msgs[0];
                OutputStream os = socket.getOutputStream();
                OutputStreamWriter osw = new OutputStreamWriter(os);
                BufferedWriter bw = new BufferedWriter(osw);
                bw.write(msgToSend);

                bw.flush();

                //System.out.print(msgToSend);
                socket.close();
                }
                

            } catch (UnknownHostException e) {
//                e.printStackTrace();
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
//                e.printStackTrace();
                Log.e(TAG, "ClientTask socket IOException");
            }

            return null;
        }
    }
}