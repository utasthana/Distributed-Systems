package edu.buffalo.cse.cse486586.groupmessenger1;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.util.Log;

import java.util.HashMap;


public class GroupMessengerProvider extends ContentProvider {
    SQLiteDatabase db;
    Dbhandler dbhandler;
    HashMap<String, String> hm = new HashMap<String, String>();

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // You do not need to implement this.
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        String TAG = "successful";
        String filename = values.getAsString("key");
        String myvalues = values.getAsString("value");
        //dbhandler.getWritableDatabase();
        //ContentValues contentValues=new ContentValues();
      //  values.put(Dbhandler.getTableName(), filename);
        //values.put(Dbhandler.getTableName(), myvalues);
        // long count=db.insert(Dbhandler.getTableName(), null, values);
        // Log.i(TAG, "Insertion success # " + Long.toString(count));
         // db.insert(Dbhandler.getTableName(), null, values);
          //db.close();
        // getContext().getContentResolver().notifyChange(uri, null);

       /* Log.v("insert", values.toString());
        //Log.v("insert", String.valueOf(count));
        values.put(Dbhandler.getTableName(), filename);
        values.put(Dbhandler.getTableName(), myvalues);
        long id = db.insert(Dbhandler.getTableName(), null, values);
        getContext().getContentResolver().notifyChange(uri, null); */
      hm.put(values.get("key").toString(), values.get("value").toString());
        Log.v("insert", values.toString());
        return uri;  //.parse(Dbhandler.getTableName() + "/" + id);
    }

    @Override
    public boolean onCreate() {
        // If you need to perform any one-time initialization task, please do it here.
      //  dbhandler = new Dbhandler(getContext());
        return false;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        /*Cursor cursor;
        db=dbhandler.getReadableDatabase();
         cursor=db.query(Dbhandler.getTableName(), projection, selection, selectionArgs, null, null,sortOrder);
        cursor.setNotificationUri(getContext().getContentResolver(), uri);

        Log.v("query", selection);
        return cursor;
        SQLiteQueryBuilder qBuilder = new SQLiteQueryBuilder();
        qBuilder.setTables(Dbhandler.getTableName());
        //sqlDB = dbHelper.getWritableDatabase();
                qBuilder.appendWhere("key" + "='" + selection + "'");

        Cursor c = qBuilder.query(db,
                projection,
                null,
                selectionArgs,
                null,
                null,
                sortOrder);
        c.setNotificationUri(getContext().getContentResolver(), uri);
        Log.v("query", selection);
        return c; */
       MatrixCursor mc = new MatrixCursor(new String[]{"key", "value"});
        if (hm.containsKey(selection)) {
            MatrixCursor.RowBuilder newRow = mc.newRow();
            newRow.add("key", selection);
            newRow.add("value", hm.get(selection));
            return mc;

        }
        return null;
    }
}
