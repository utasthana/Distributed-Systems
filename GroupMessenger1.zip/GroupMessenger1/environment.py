#!/usr/bin/env python

#Modify once acccording to your setup
WORKSPACE = "/home/uttara/AndroidStudioProjects"

#Modify the below lines for each project
PROJECT_NAME = "GroupMessenger1"
#Modify if using DB
DB_NAME = "groupmsg"
TABLE_NAME = "group_msgs"
MAIN_ACTIVITY = "GroupMessengerActivity"

#DO NOT MODIFY
PREFIX = "edu.buffalo.cse.cse486586"
PROJECT_EXT = PROJECT_NAME.lower()
