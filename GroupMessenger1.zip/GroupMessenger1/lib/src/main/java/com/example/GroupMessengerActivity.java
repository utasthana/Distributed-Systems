package com.example;

public class GroupMessengerActivity {
}
