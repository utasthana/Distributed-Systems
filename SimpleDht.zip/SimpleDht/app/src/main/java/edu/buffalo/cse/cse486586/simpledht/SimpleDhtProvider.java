package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Formatter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import android.database.MatrixCursor;
import android.content.Context;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDhtProvider extends ContentProvider {
    public static final int SERVER_PORT = 10000;
    private SQLiteDatabase db_gpmsz;
    private DataStorage dbStorage;

    String sendPort = "11108";
    static final String TAG = SimpleDhtProvider.class.getSimpleName();
    String pred = null;
     public static final String amp_sign = "&";
    final String pred_CONS = "pred";
    final String succ_CONS = "succ";
    String myPort;
    private Uri mUri;
	 boolean mainport = true;
    String queryData = null;
    public static final String DB_KEY = "key";
    String succ = null;
	 String[] portsArr = null;
   
    boolean mutex = true;
    static int count = 0;
    static HashSet<String> portSet = new HashSet<String>();
   
    public static final String DB_VAL = "value";
    static HashSet<String> set_ports = new HashSet<String>();

   


    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        if (!selection.contains("@") && !selection.contains("*")) {
            if (myPort.equals(pred) && myPort.equals(succ)) {
                return deleteKey(selection);
            } else {
                String msg = selection + ";";
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, sendPort);
            }
        } else if (selection.contains("@")) {
            return deleteL();
        } else {
            if (myPort.equals(pred) && myPort.equals(succ)) {
                deleteL();
            } else {  ArrayList<String> ports_num = new ArrayList<String>();
                int xyz=11108; int i=0;
                while(i<5) {
                    xyz+=4;
                    String tmp=Integer.toString(xyz);
                    ports_num.add(tmp);
                    i++;
                }
                String[] portsArrNw = {"11108", "11112", "11116", "11120", "11124"};
                int parlen=portsArrNw.length;
                for (int j = 0; j < parlen; j++) {
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, selection+">", portsArrNw[j]);
                }
            }
        }
        return 0;
    }



    int deleteKey(String selection) {
        SQLiteDatabase dbk = dbStorage.getWritableDatabase();
        return dbk.delete(TABLE_NAME, "key='" + selection + "'", null);
    }

    int deleteL() {
        SQLiteDatabase dbak = dbStorage.getWritableDatabase();
        return dbak.delete(TABLE_NAME, null, null);
    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        String tmp=null;
        return null;
    }
    public <K extends Comparable,V extends Comparable> LinkedHashMap<K,V> sortByKeys(LinkedHashMap<K,V> map){
        List<K> keys = new LinkedList<K>(map.keySet());
        Collections.sort(keys, (Comparator<? super K>) new Comparator<String>() {
            @Override
            public int compare(String first, String second) {
                Collator collator = Collator.getInstance(Locale.getDefault());
                return collator.compare(first, second);
            }
        });

        LinkedHashMap<K,V> sortedMap = new LinkedHashMap<K,V>();
        for(K key: keys){
            sortedMap.put(key, map.get(key));
        }

        return sortedMap;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        String temp_key=(String) values.getAsString(DB_KEY);
        String key = temp_key;
        String value = (String) values.getAsString(DB_VAL);
        try {
            String hashkey = genHash(key);
            int x1=Integer.parseInt(myPort);
            int y1=x1/2;
            int x2=Integer.parseInt(pred);
            int y2=x2/2;
            int x3=Integer.parseInt(succ);
            int y3=x3/2;
            String hashvalMyPort = genHash(y1 + "");
            String hashvalPredPort = genHash(y2+ "");
            String hashvalSuccPort = genHash(y3+ "");

            int keyMyPortComp = hashkey.compareTo(hashvalMyPort);
            int keyPredPortComp = hashkey.compareTo(hashvalPredPort);
            int keySuccPortComp = hashkey.compareTo(hashvalSuccPort);
            int myPortPredPortComp = hashvalMyPort.compareTo(hashvalPredPort);
            int myPortSuccPortComp = hashvalMyPort.compareTo(hashvalSuccPort);


            if (myPort.equals(succ) && myPort.equals(pred)) {
                return writeIntoDB(uri, values);
            } else {
                if (!(myPortPredPortComp >= 0) && myPortSuccPortComp < 0) {
                    if (keyMyPortComp > 0) {
                        if (!(keyPredPortComp <= 0)) {
                            return writeIntoDB(uri, values);
                        } else {
                            String dash_="---";
                            String hash="#";
                            String msg = key + dash_ + value;
                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, succ);
                        }
                    } else {
                        return writeIntoDB(uri, values);
                    }
                } else {
                    if (keyMyPortComp > 0) {
                        String dash_="---";
                        String hash="#";
                        String msg = key + dash_ + value;
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, succ);
                    } else if (!(keyPredPortComp <= 0)) {
                        return writeIntoDB(uri, values);
                    } else {String dash_="---";
                        String msg = key + dash_ + value;
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, pred);
                    }
                }
            }
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "NoSuchAlgorithmException Exception");
        }
        return null;
    }


    Uri writeIntoDB(Uri uri, ContentValues values) {

        String key = (String) values.getAsString(DB_KEY);
        Log.d("writeIntoDB ", key);
        db_gpmsz = dbStorage.getWritableDatabase();
        long row_id = db_gpmsz.insertWithOnConflict(TABLE_NAME, null, values, 5);

        if (row_id != -1) {
            return uri.withAppendedPath(uri, Long.toString(row_id));
        }
        return uri;
    }

    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    @Override
    public boolean onCreate() {
        dbStorage = new DataStorage(getContext());
        mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        portSet.add(sendPort);

        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
            succ = myPort;
            pred = myPort;
            if (!myPort.equals(sendPort)) {
                Log.d(TAG, "portStr: " + portStr);
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort + amp_sign, "11108");
            }

        } catch (IOException e) {
        }
        return true;
    }
    public void SwitchSubstring1 (String msg_record) {
        String cases = msg_record;

        int i;

        for(i = 0; i < cases.length(); i++)
        {  char cc = cases.charAt(i);

            switch(cc) {
                case '>': //someSubString
                    // deleteLocalKeys();
                    break;
                case '$': //anotherSubString
                    queryAllMsgs(msg_record);
                    break;
                case '%': //yetanotherSubString
                {   queryData = msg_record;
                    mutex = false;}
                break;
                case ';':
                    //deleteDHT(msg_record);
                    break;
                default:

            }}

    }

    @SuppressWarnings("ResourceType")
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {

            ServerSocket serverSocket = sockets[0];

            try {
                while (true) {
                    Socket socket = serverSocket.accept();
                    BufferedReader brReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String recMsg = brReader.readLine().trim();
                    Log.d(TAG, "iN SERVER TASK MESSAGE RECEIVED IS " + recMsg);
                    if (recMsg.contains("---")) {
                        Log.d("InServInsert", myPort + "#" + recMsg.split("---")[0]);
                        ContentValues cv = new ContentValues();
                        cv.put(DB_KEY, recMsg.split("---")[0]);
                        cv.put(DB_VAL, recMsg.split("---")[1]);
                        insert(mUri, cv);
                    } else if (recMsg.contains("__")) {
                        Log.d("severQueryDht", myPort + "#" + recMsg);
                        queryDHT(recMsg);
                    } else if (recMsg.contains("%")) {
                        queryData = recMsg;
                        mutex = false;
                    } else if (recMsg.contains("$")) {
                        queryAllMsgs(recMsg);
                    } else if (recMsg.contains("~~")) {
                        queryData = recMsg;
                        mutex = false;
                    } else if (recMsg.contains(";")) {
                        Log.d("serverDel", recMsg);
                        String selection =recMsg;
                        StringBuilder myName = new StringBuilder(selection);
                        int temp_index=selection.indexOf(';');
                        myName.setCharAt(temp_index, '\0');
                        String key = selection.replace(";", "");
                        String portToSend = null;

                        try {
                            String hashkey = genHash(key);
                            int x1=Integer.parseInt(myPort);
                            int y1=x1/2;
                            int x2=Integer.parseInt(pred);
                            int y2=x2/2;
                            int x3=Integer.parseInt(succ);
                            int y3=x3/2;

                            String hashvalMyPort = genHash(y1 + "");
                            String hashvalPredPort = genHash(y2 + "");
                            String hashvalSuccPort = genHash(y3 + "");
                            int keyMyPortComp = hashkey.compareTo(hashvalMyPort);
                            int keyPredPortComp = hashkey.compareTo(hashvalPredPort);
                            int keySuccPortComp = hashkey.compareTo(hashvalSuccPort);
                            int myPortPredPortComp = hashvalMyPort.compareTo(hashvalPredPort);
                            int myPortSuccPortComp = hashvalMyPort.compareTo(hashvalSuccPort);

                            if (myPort.equals(pred) && myPort.equals(succ)) {
                                deleteKey(key);
                            } else {
                                if (myPortPredPortComp < 0 && myPortSuccPortComp < 0) {
                                    if (keyMyPortComp > 0) {
                                        if (keyPredPortComp <= 0) {
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, selection, succ);
                                        } else {
                                            deleteKey(key);
                                        }
                                    } else {
                                        deleteKey(key);
                                    }
                                } else {
                                    if (keyMyPortComp > 0) {
                                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, selection, succ);
                                    } else if (keyPredPortComp <= 0) {
                                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, selection, pred);
                                    } else {
                                        deleteKey(key);

                                    }
                                }
                            }
                        } catch (NoSuchAlgorithmException e) {
                            Log.e(TAG, "NoSuchAlgorithmException Exception");
                        }


                    } else if (recMsg.contains(">")) {
                        Log.d("serverDelAll", recMsg);
                        deleteL();
                    } else if (recMsg.contains("::")) {
                        StringBuilder myName = new StringBuilder(recMsg);
                        int temp_index=recMsg.indexOf(':');
                        myName.setCharAt(temp_index, '\0');
                        String portsd = recMsg.replace("::", "");
                        String portStr = "";
                        Iterator<String> it = portSet.iterator();
                        for (Iterator<String> flavoursIter = portSet.iterator(); flavoursIter.hasNext();){
                            String x=(flavoursIter.next());
                        }
                        Log.d("getAllPorts portSet", portSet.toString());
                        while (it.hasNext()) {
                            portStr += it.next() + "!!";
                        }

                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, portStr, portsd);

                    } else if (recMsg.contains("!!")) {
                        portsArr = recMsg.split("!!");
                        mainport = false;
                    } else if (recMsg.contains(amp_sign)) {
                        if (!recMsg.contains("#"))
                        {   StringBuilder myName = new StringBuilder(recMsg);
                            int temp_index=recMsg.indexOf(amp_sign);
                            myName.setCharAt(temp_index, '\0'); portSet.add(recMsg.replace(amp_sign, ""));}

                        try {
                            String rm=recMsg;StringBuilder myName = new StringBuilder(rm);
                            int temp_index=rm.indexOf(amp_sign);
                            myName.setCharAt(temp_index, '\0');
                            recMsg = recMsg.replace(amp_sign, "");
                            if (recMsg.contains("#")) {
                                if (recMsg.contains(pred_CONS)) {
                                    pred = recMsg.split("#")[0];
                                } else if (recMsg.contains(succ_CONS)) {
                                    succ = recMsg.split("#")[1];
                                } else {
                                    pred = recMsg.split("#")[0];
                                    succ = recMsg.split("#")[1];
                                }

                            } else {
                                String recvPort = recMsg;
                                int x1=Integer.parseInt(recvPort);
                                //   x1=4*x1;
                                int y1=x1/2;
                                // y1=x1/4;

                                int x2=Integer.parseInt(myPort);
                                //  x2=4*x2;
                                int y2=x2/2;
                                //y2=x2/4;
                                String hashvalRecevPort = genHash(y1 + "");
                                String hashvalMyPort = genHash(y2 + "");
                                int si=Integer.parseInt(succ) / 2;
                                String hashvalSuccPort = genHash(si + "");
                                int pi=Integer.parseInt(pred) / 2;
                                String hashvalPredPort = genHash(pi + "");

                                int recPortMyPortComp = hashvalRecevPort.compareTo(hashvalMyPort);
                                int recPortPredPortComp = hashvalRecevPort.compareTo(hashvalPredPort);
                                int myPortPredPortComp = hashvalMyPort.compareTo(hashvalPredPort);
                                int recPortSuccPortComp = hashvalRecevPort.compareTo(hashvalSuccPort);
                                int myPortSuccPortComp = hashvalMyPort.compareTo(hashvalSuccPort);

                                if (myPort.equals(succ) && myPort.equals(pred)) {
                                    succ = recvPort;
                                    pred = recvPort;
                                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, myPort + "#" + myPort + amp_sign, recvPort);
                                } else {
                                    if (recPortMyPortComp < 0) {
                                        if (recPortPredPortComp > 0) {
                                            String msg = pred + "#" + myPort + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, recvPort);
                                            msg = succ_CONS + "#" + recvPort + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, pred);
                                            pred = recvPort;
                                        } else if (myPortPredPortComp < 0) {
                                            String msg = pred + "#" + myPort + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, recvPort);
                                            msg = succ_CONS + "#" + recvPort + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, pred);
                                            pred = recvPort;
                                        } else {
                                            String msg = recvPort + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, pred);
                                        }

                                    }

                                    else if (recPortMyPortComp > 0) {
                                        String mz1, mz2, mz3;
                                        if (recPortSuccPortComp < 0) {
                                            mz1 = myPort + "#" + succ + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, mz1, recvPort);
                                            mz1 = recvPort + "#" + pred_CONS + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, mz1, succ);
                                            succ = recvPort;
                                        } else if (myPortSuccPortComp > 0) {
                                            mz2 = myPort + "#" + succ + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, mz2, recvPort);
                                            mz2 = recvPort + "#" + pred_CONS + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, mz2, succ);
                                            succ = recvPort;
                                        } else {
                                            mz3 = recvPort + amp_sign;
                                            new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, mz3, succ);
                                        }
                                    }
                                }
                            }
                        } catch (NoSuchAlgorithmException e) {
                            Log.d(TAG, e.getMessage());
                        }



                    }
                    brReader.close();
                    socket.close();
                }

            } catch (IOException e) {
                Log.d(TAG, e.getMessage());
            }
            return null;
        }
    }



    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {

            try {

                String port = msgs[1];
                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(port));
                // Socket socket = serverSocket.accept();
                BufferedReader brReader = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                String msg_Send = msgs[0];
                PrintWriter pw = new PrintWriter(socket.getOutputStream(), true);
                pw.write(msg_Send);
                pw.flush();
                pw.close();
                socket.close();
            } catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.d("TAG ", msgs[1]);
            }
            return null;
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {

        String recvmsg = selection;

        return queryHandler(selection);
    }

    void queryAllMsgs(String recMsg) {
        String portTosd = recMsg.replace("$", "");
        Log.d("portTosd ", portTosd);
        String[] temp_arr={"select ", "* ", "from "};
        String str = temp_arr[0]+temp_arr[1]+temp_arr[2] + TABLE_NAME;
        SQLiteDatabase db = dbStorage.getReadableDatabase();
        Cursor cursor = db.rawQuery(str, null);

        String keyValPairs = "";
        //   Iterator<String> it1 = set_ports.iterator();
        for (Iterator<String> it1 = set_ports.iterator(); it1.hasNext();){
            String x=(it1.next());
        }
        while (cursor.moveToNext()) {
            keyValPairs += (cursor.getString(0) + "," + cursor
                    .getString(1));
            keyValPairs += "~~";
        }


        if (keyValPairs == "") {
            Log.d("EMpty keyvalues pairs ", myPort);
            keyValPairs = "~~";
        }


        new ClientTask().executeOnExecutor(
                AsyncTask.SERIAL_EXECUTOR, keyValPairs,
                portTosd);

    }

    Cursor queryHandler(String recvmsg) {
        if (!recvmsg.contains("@") && !recvmsg.contains("*")) {
            String key = recvmsg;
            if (myPort.equals(succ) && myPort.equals(pred)) {
                return getCursorKey(recvmsg);
            } else {
                String msg = key + "__" + myPort;
               
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,
                        msg, sendPort);
                while (mutex) {

                }
                Log.d("queryData", queryData);
                String[] keyval = queryData.split("%");
                String split_key = keyval[0];
                MatrixCursor mc;
                String arr[] = new String[]{DB_KEY, DB_VAL};
                String split_val = keyval[1];
                String rowz[] = new String[]{split_key, split_val};

                mc = new MatrixCursor(arr);
                mc.addRow(rowz);
                mutex = true;
                queryData = null;
                return mc;
            }
        } else if (recvmsg.contains("@")) {
            String[] temp_arr={"select ", "* ", "from "};
            String str = temp_arr[0]+temp_arr[1]+temp_arr[2] + TABLE_NAME;
            SQLiteDatabase db = dbStorage.getReadableDatabase();
            Cursor cursor = db.rawQuery(str, null);
            return cursor;
        } else {
            if (recvmsg.contains("*")) {
                if (myPort.equals(pred) && myPort.equals(succ)) {
                    String str;
                    String[] temp_arr={"select ", "* ", "from "};
                    String str1 = temp_arr[0]+temp_arr[1]+temp_arr[2] + TABLE_NAME;
                    db_gpmsz = dbStorage.getReadableDatabase();
                    str = "select * from " + TABLE_NAME;
                    Cursor cursor = db_gpmsz.rawQuery(str, null);
                    return cursor;
                } else {
                    String arrMat[] = new String[]{DB_KEY, DB_VAL};
                    MatrixCursor matCursor = new MatrixCursor(arrMat);
                    String msg1 = myPort + "::";
                    mainport = true;
                    Log.d("queryHandler", myPort);
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg1, sendPort);
                    while (mainport) {

                    }
                    int pas=portsArr.length;
                    for (int n = 0; n < pas; n++) {
                        queryData = null;
                        mutex = true;
                        String msg = myPort + "$";
                        Log.d("queryTask", myPort);
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, portsArr[n]);
                        while (mutex) {

                        }

                        if (!queryData.equals("~~")) {
                            Log.d("queryDataFInal", queryData);
                            String[] arr = queryData.split("~~");
                            int as=arr.length;
                            int k1=0;
                            String ky, val;
                            // String val;
                            while(k1 < as) {
                                ky = arr[k1].split(",")[0];
                                val = arr[k1].split(",")[1];
                                String[] stm = new String[]{ky, val};
                                matCursor.addRow(stm);
                                k1++;
                            }
                        }
                    }
                    mutex = true;
                    queryData = null;
                    Log.d("cursolen ", matCursor.getCount() + "");
                    portsArr = null;
                    return matCursor;
                }
            }
        }
        return null;
    }

    Cursor queryDHT(String recvmsg) {
	 String portToSend = null;
        String key = recvmsg.split("__")[0];
       
        boolean flag = recvmsg.contains("__");
        Log.d("recvmsg", recvmsg);
        try {
            if (flag) {
                portToSend = recvmsg.split("__")[1];
            }
            Log.d("portToSend ", portToSend);
            String hashkey = genHash(key);
            int hvi=Integer.parseInt(myPort) / 2;
            //  int yvi=hvi*2;
            //  yvi=yvi/2;
            String hashvalMyPort = genHash(hvi + "");

            int pi=Integer.parseInt(pred) / 2;
            //  int yi=pi*2;
            //  yi=pi/2;
            String hashvalPredPort = genHash(pi + "");

            int si= Integer.parseInt(succ) / 2;
            //  int syi=si*4;
            //syi=si/4;
            String hashvalSuccPort = genHash(succ+ "");


            int keyMyPortComp = hashkey.compareTo(hashvalMyPort);
            int keyPredPortComp = hashkey.compareTo(hashvalPredPort);
            int myPortPredPortComp = hashvalMyPort.compareTo(hashvalPredPort);
            int myPortSuccPortComp = hashvalMyPort.compareTo(hashvalSuccPort);


            if (myPortPredPortComp < 0 && myPortSuccPortComp < 0) {
                if (keyMyPortComp > 0) {
                    if (keyPredPortComp > 0) {
                        Cursor crs = getCursorKey(key);
                        crs.moveToFirst();
                        String keyf = crs.getString(0);
                        String valuef = crs.getString(1);
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,keyf + "%" + valuef, portToSend);
                    } else {
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, recvmsg, succ);
                    }
                } else {
                    Cursor crs = getCursorKey(key);
                    crs.moveToFirst();
                    String keyf = crs.getString(0);
                    String valuef = crs.getString(1);
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, keyf + "%" + valuef, portToSend);
                }
            } else {  //-------------------------------------------------------------------------------------------------
                if (!(keyMyPortComp <= 0)) {
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, recvmsg, succ);
                } else if (keyPredPortComp > 0) {
                    Cursor crs = getCursorKey(key);
                    crs.moveToFirst();
                    String keyf = crs.getString(0);
                    String valuef = crs.getString(1);
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR,keyf + "%" + valuef, portToSend);
                } else {
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, recvmsg, pred);
                }
            }

        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "NoSuchAlgorithmException");
        }
        return null;
    }

    public Cursor getCursorKey(String selection) {
        db_gpmsz = dbStorage.getReadableDatabase();
        Cursor cursor;
        String[] temp_arr={"select ", "* ", "from "};
        String str = temp_arr[0]+temp_arr[1]+temp_arr[2] + TABLE_NAME
                + " where " + DB_KEY + "='" + selection
                + "'";
        cursor = db_gpmsz.rawQuery(str, null);
        return cursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        int x=1;
        int y=1;
        int z=x-y;
        return z;
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        String dec_cod="%02x";
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format(dec_cod, b);
        }
        return formatter.toString();
    }


    static String TABLE_NAME = "GroupMsgTable";
    //static int DB_VERSION = 2;


    private static class DataStorage extends SQLiteOpenHelper {
        static String DB_NAME = "GroupDB";

        String CREATE_DB_TABLE =
                " CREATE TABLE " + TABLE_NAME +
                        " ( key TEXT NOT NULL UNIQUE, value TEXT NOT NULL);";

        DataStorage(Context context) {
            super(context, DB_NAME, null, 2);
            Log.d("DataStorage", "db");
            Log.d("create", CREATE_DB_TABLE);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {


            db.execSQL(CREATE_DB_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,
                              int newVersion) {
            db.execSQL(TABLE_NAME);
            onCreate(db);
        }
    }
}abstract class ContextWrapper extends Context
{  ContextWrapper mBase;
    @Override
    public Context getApplicationContext() {

        return mBase.getApplicationContext();
    }
    protected ContextWrapper attachBaseContext(Context base) {
        if (mBase != null) {
            throw new IllegalStateException("Base context already set");
        }
        mBase = (ContextWrapper)base;
        return mBase;
    }
}





class NHL {
    public String HC;
    public String portNum;

    NHL(String HC,String portNum){
        this.portNum = portNum;
        this.HC = HC;

    }

    public NHL() {

        this.portNum = null;
        this.HC =null;
    }
}


class MyCmp implements Comparator<NHL> {
    @Override
    public int compare(NHL o1, NHL o2) {
        if (o1.HC.compareTo(o2.HC) <0) {
            return -1;
        } else if (o1.HC.compareTo(o2.HC) < 0) {
            return 1;
        }
        return 0;
    }}




